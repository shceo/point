abstract class AppRoutes {
  static const String afterSplashscreen = '/afterSplashscreen';
  static const String splashscreen = '/splashscreen';
  static const String mainPage = '/';
}