// lib/src/ui/screens/payment_screen.dart

import 'dart:convert';
import 'dart:developer';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:davlat/src/data/db/database.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:uuid/uuid.dart';
import 'package:webview_flutter/webview_flutter.dart';

/// Репозиторий для создания платежа на YooKassa
class CassaRepo {
  static const String shopId = '1054000';
  static const String secretKey =
      'test_wdpD9DOXt65p1Tt02FK9LjGLyjbxz-19mYilgdc8Sj4';

  /// Инициализируем платёж и возвращаем URL для WebView
  static Future<String> createPaymentUrl(double amount) async {
    const api = 'https://api.yookassa.ru/v3/payments';
    final idKey = const Uuid().v4();

    final resp = await http.post(
      Uri.parse(api),
      headers: {
        'Authorization':
            'Basic ' + base64Encode(utf8.encode('$shopId:$secretKey')),
        'Content-Type': 'application/json',
        'Idempotence-Key': idKey,
      },
      body: jsonEncode({
        'amount': {
          'value': amount.toStringAsFixed(2),
          'currency': 'RUB',
        },
        'payment_method_data': {'type': 'bank_card'},
        'confirmation': {
          'type': 'redirect',
          // YooKassa вставит этот return_url в кнопку "вернуться назад"
          'return_url': 'myapp://payment-callback',
        },
        'capture': true,
      }),
    );

    if (resp.statusCode != 200) {
      log('YooKassa error: ${resp.statusCode}\n${resp.body}');
      throw Exception('Не удалось инициализировать платёж');
    }

    final data = jsonDecode(resp.body);
    return data['confirmation']['confirmation_url'] as String;
  }
}

/// Экран, внутри которого мы запустим WebView и дождёмся диплинка
class PaymentScreen extends StatefulWidget {
  final double totalAmount;
  const PaymentScreen({Key? key, required this.totalAmount}) : super(key: key);
  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  late final WebViewController _controller;
  String? _url;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _startPayment();
  }

  Future<void> _startPayment() async {
    try {
      final url = await CassaRepo.createPaymentUrl(widget.totalAmount);
      _controller = WebViewController()
        ..setJavaScriptMode(JavaScriptMode.unrestricted)
        ..setNavigationDelegate(
          NavigationDelegate(
            onNavigationRequest: (req) {
              ;

              // ловим диплинк
              if (req.url.startsWith('myapp://payment-callback')) {
                final uid = FirebaseAuth.instance.currentUser!.uid;
                final userRef =
                    FirebaseFirestore.instance.collection('users').doc(uid);

                // 1) Увеличиваем общий баланс
                userRef.set({
                  'loyalty': FieldValue.increment(5)
                }, SetOptions(merge: true)).catchError(
                    (e) => debugPrint('Ошибка loyalty: $e'));

                // 2) Пишем в историю
                userRef.collection('loyaltyHistory').add({
                  'points': 5,
                  'action': 'Заказ оплачен',
                  'timestamp': FieldValue.serverTimestamp(),
                }).catchError((e) => debugPrint('Ошибка истории: $e'));

                _showSuccess();
                return NavigationDecision.prevent;
              }
              return NavigationDecision.navigate;
            },
            onPageStarted: (_) => setState(() => _loading = true),
            onPageFinished: (_) => setState(() => _loading = false),
          ),
        )
        ..loadRequest(Uri.parse(url));

      setState(() => _url = url);
    } catch (e) {
      _showError('Ошибка', e.toString());
    }
  }

  Future<void> _showSuccess() async {
    // 1) Считаем всё, что сейчас в корзине
    final db = DatabaseService();
    final basket = await db.getBasketItems();
    for (var item in basket) {
      await db.addOrder(item);
    }
    await db.clearBasket();
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text('Успех'),
        content: const Text('Оплата успешно завершена!',
            textAlign: TextAlign.center),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context)
                ..pop() // закрыть диалог
                ..pop(); // вернуться из PaymentScreen
            },
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  void _showError(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(title),
        content: Text(msg, textAlign: TextAlign.center),
        actions: [
          TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('OK')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_url == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    return Scaffold(
      appBar: AppBar(title: const Text('Оплата')),
      body: Stack(
        children: [
          WebViewWidget(controller: _controller),
          if (_loading) const Center(child: CircularProgressIndicator()),
        ],
      ),
    );
  }
}
